network = [{"data":{"id":"N1"},"position":{"x":779.5, "y":5 }},
           {"data":{"id":"N2"},"position":{"x":979.5, "y":300 }},
           {"data":{"source":"N1","target":"N2","id":"e1"}}];
